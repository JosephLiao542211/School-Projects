from functions import *


def main():
    print("You will insert numbers if they are all even or odd "
          "they will return True otherwise they will return False")
    numlist=[]
    numt=0
    start=(input("please enter yes to start the activity"))
    if start.upper()=="YES":
        while True:
            num=(input("please enter numbers"))
            try:
                numt==int(num)
            except:
                print("invalid input try again")
            if type(numt)==int:
                numlist.append(int(num))
                cont=input("enter yes to continue to input numbers "
                           "anything else to complete activity")
                if cont.upper()=="YES":
                    continue
                else:
                    break

        all_odd_or_even(numlist)
    else:
        return


main()



from functions import *
def main():
    print(friendship_to_dictionary())
    print("\n")
    name=input("Insert name of friend you want to look up")
    print(allmyfriends(name))
    print("\n")
    (friendship_degree(friendship_to_dictionary()))



main()

def all_odd_or_even(arg):
    if len(arg)>=1 and ([True for i in arg if (type(i)==int)]) \
            and (all(i%2==0 for i in arg) or all(i%2==1 for i in arg)):
        print("True")
    else:
        print("False")

def friendship_to_dictionary():
    d={}

    allname=[]
    f=open("friendship.txt")
    for row in f:
        row = row.strip().split()
        allname.append(row)

    for set in allname:
        if set[0] not in d:
            d[set[0]]=set[1]
        else:
            d[set[0]]=[d[set[0]],set[1]]

    return (d)

def allmyfriends(friend):
    dictionary=friendship_to_dictionary()
    friend_count=[]
    if type(dictionary[friend])==str:
        friend_count.append((dictionary[friend]))
    else:
        for x in range(len(dictionary[friend])):

         friend_count.append((dictionary[friend][x]))

    for i in dictionary:
        if friend in dictionary[i]:
            friend_count.append(i)

    return friend_count



def friendship_degree(dictionary):
    for i in dictionary:
         print(i,"has",len(allmyfriends(i)),"friends","("+", ".join(allmyfriends(i))+")")
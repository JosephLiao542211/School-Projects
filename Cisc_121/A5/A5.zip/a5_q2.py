from stack_classes import *
# Create a new stack
s = Stack()

# Push some items onto the stack
s.push("A")
s.push("B")
s.push("C")
s.push("D")
s.push("1")
s.push("3")
s.push(2)
s.push("9")
s.push("12")
s.push(12)
# Print the original stack
print("Original stack:", s)

# Reverse the stack
s.reverse()


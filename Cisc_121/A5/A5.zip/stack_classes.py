"""
-------------------------------------------------------
Array version of the Stack ADT.
-------------------------------------------------------
Author:  Joseph Liao
ID:      20366481
Email: 22jl41@queensu.ca
Section: CISC121 Winter 2023
-------------------------------------------------------
"""
class Stack:
    def __init__(self):
        """
        -------------------------------------------------------
        Initializes an empty stack. Data is stored in a Python list.
        Use: stack = Stack()
        -------------------------------------------------------
        Returns:
            a new Stack object (Stack)
        -------------------------------------------------------
        """

        self.items = []
    def push(self, item):
        """
        -------------------------------------------------------
        Pushes a copy of value onto the top of the stack.
        Use: stack.push(value)
        -------------------------------------------------------
        Parameters:
            value - value to be added to stack (?)
        Returns:
            None
        -------------------------------------------------------
        """
        self.items.append(item)
    def pop(self):

        return self.items.pop()
    def reverse(self):
        aux_stack = Stack()
        while not self.is_empty():
            aux_stack.push(self.pop())
        self.items = aux_stack.items

        print("reversed:", self)
    def peek(self):
        return self.items[-1] #get the last element

    def is_empty(self):
        """
        -------------------------------------------------------
        Determines if the stack is empty.
        Use: b = stack.is_empty()
        -------------------------------------------------------
        Returns:
            True if stack is empty, False otherwise
        -------------------------------------------------------
        """
        return self.items == []
    def __str__(self):
        return str(self.items)



public class BadOrder extends Exception {
    public BadOrder(String message) {
        super(message);
    }
}
public class BadMember extends Exception {
    public BadMember(String message) {
        super(message);
    }
}